﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Linq;

namespace Selenium.Teste
{
    public static class WebDriverExensions
    {
        public static string GetText(this IWebDriver webDriver, By by)
        {
            IWebElement webElement = webDriver.FindElement(by);
            return webElement.Text;
        }
        public static void SetText(this IWebDriver webDriver, By by, string text)
        {
            IWebElement webElement = webDriver.FindElement(by);
            webElement.SendKeys(text);
        }

        public static void SelectOptionByIndex(this IWebDriver driver, By by, int index)
        {
            var combo = new SelectElement(driver.FindElement(by));
            combo.SelectByIndex(index);
        }
        public static void SelectOptionByValue(this IWebDriver driver, By by, string value)
        {
            var combo = new SelectElement(driver.FindElement(by));
            combo.SelectByValue(value);
        }
    }
}

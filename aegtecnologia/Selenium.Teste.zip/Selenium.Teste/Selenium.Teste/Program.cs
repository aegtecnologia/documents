﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Selenium.Teste
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inicio do Programa");
            TesteFinal();
            Console.WriteLine("Fim do Programa");
            Console.ReadKey();
        }

        static void MultDriver()
        {
            var drive = Environment.CurrentDirectory;

            IWebDriver driver1 = null;
            IWebDriver driver2 = null;

            try
            {
                driver1 = new ChromeDriver(drive);
                driver2 = new ChromeDriver(drive);

                driver1.Manage().Window.Maximize();
                driver2.Manage().Window.Maximize();
                //Navigate to google page
                driver1.Navigate().GoToUrl("https://portal-corban.interfile.com.br");
                driver2.Navigate().GoToUrl("https://portal-corban.interfile.com.br");

            }
            catch (Exception erro)
            {
                Console.WriteLine($"Erro: {erro.Message}");
            }
            finally
            {
                if (driver1 != null) driver1.Close();
                if (driver2 != null) driver2.Close();
            }
        }
        static void TesteCredcesta()
        {
            var drive = Environment.CurrentDirectory;

            IWebDriver driver = null;

            try
            {
                driver = new ChromeDriver(drive);

                driver.Manage().Window.Maximize();
                //Navigate to google page
                driver.Navigate().GoToUrl("https://portal-corban.interfile.com.br");


                driver.SetText(By.Name("Input.Login"), "Admin");
                driver.SetText(By.Name("Input.Password"), "Inter@2019");

                driver.FindElements(By.TagName("button")).Where(e => e.Text.Contains("Entrar")).SingleOrDefault().Click();

                //var resposta = new WebDriverWait(driver, TimeSpan.FromSeconds(10)).Until(ExpectedConditions.TextToBePresentInElement,("https://portal-corban.interfile.com.br"));

                //if (!resposta) throw new Exception("Erro durante login");

                driver.Navigate().GoToUrl("https://portal-corban.interfile.com.br/relatorios/propostas");

                driver.SelectOptionByIndex(By.Name("Filtros.CorbanId"), 1);


            }
            catch (Exception erro)
            {
                Console.WriteLine($"Erro: {erro.Message}");
            }
            finally
            {
                if (driver != null) driver.Close();
            }
        }

        static void TesteFinal()
        {
            var service = new WhatsappService();
            var mensagem = $"Em brasilia são {DateTime.Now.ToString("HH:mm")}. - Repiiita!!!";
            var contatos = new List<Contato>()
            {
                new Contato()
                {
                    Nome="Anderson",
                    Telefone = "5511965021254"
                },
                new Contato()
                {
                    Nome="Junior",
                    Telefone = "5511984254152"
                },
                new Contato()
                {
                    Nome="Alexandre",
                    Telefone = "5511976730975"
                },
                 new Contato()
                {
                    Nome="Gisele",
                    Telefone = "5511965022851"
                },
            };

            var relatorio = service.EnviarMensagens(mensagem, contatos);

            var json = Newtonsoft.Json.JsonConvert.SerializeObject(relatorio);

            Console.WriteLine($"Retorno: {relatorio}");

        }
        static void EnviarMensagem(IWebDriver driver, string numero, string mensagem)
        {
            var url = $"https://api.whatsapp.com/send?phone={numero}";

            driver.Navigate().GoToUrl(url);

            var waitDrive = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            if (!IsLoggedIn(driver))
            {
                var btnEnviar = waitDrive.Until(ExpectedConditions.ElementExists(By.Id("action-button")));
                btnEnviar.Click();
            }
            
            while (!IsLoggedIn(driver)) ;
            //this.WaitTocompleteLoading(4);

            var txtMensagem = waitDrive.Until(ExpectedConditions.ElementExists(By.ClassName("_3u328")));
            txtMensagem.SendKeys(mensagem);
            txtMensagem.SendKeys(Keys.Enter);
        }
        static void Teste()
        {
            IWebDriver driver = null;

            try
            {

                var pasta = Environment.CurrentDirectory;

                driver = new ChromeDriver(pasta);

                EnviarMensagem(driver, "551112345678", "Bom dia Joao! Tudo bem?");
                //EnviarMensagem(driver, "5511965021254", "Bom dia Anderson! Tudo bem?");
                //EnviarMensagem(driver, "5511965022851", "Bom dia Gisele! Tudo bem?");

                //var url = "https://api.whatsapp.com/send?phone=5511965021254";
                
                //driver.Navigate().GoToUrl(url);

                               
                //var waitDrive = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                //var btnEnviar = waitDrive.Until(ExpectedConditions.ElementExists(By.Id("action-button")));

                //btnEnviar.Click();

                //while (!IsLoggedIn(driver)) ;
                ////this.WaitTocompleteLoading(4);

                //var txtMensagem = waitDrive.Until(ExpectedConditions.ElementExists(By.ClassName("_3u328")));
                //txtMensagem.SendKeys("Bom dia Anderson");
                //txtMensagem.SendKeys(Keys.Enter);

            }
            catch (Exception erro)
            {
                Console.WriteLine($"Erro: {erro.Message}");
            }
            finally
            {
                if (driver != null) driver.Close();              
            }
        }

        static bool IsLoggedIn(IWebDriver driver)
        {
            bool flag = false;
            try
            {
                flag = driver.FindElement(By.ClassName("_2rZZg")).Displayed;
            }
            catch { flag = false; }
            return flag;
        }
    }
}
